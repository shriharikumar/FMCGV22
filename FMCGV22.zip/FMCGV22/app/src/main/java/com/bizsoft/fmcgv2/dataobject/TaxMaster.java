package com.bizsoft.fmcgv2.dataobject;

/**
 * Created by GopiKing on 17-02-2018.
 */

public class TaxMaster {

    int Id;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }
}
