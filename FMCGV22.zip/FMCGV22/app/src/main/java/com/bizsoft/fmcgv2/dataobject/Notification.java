package com.bizsoft.fmcgv2.dataobject;

/**
 * Created by GopiKing on 13-03-2018.
 */

public class Notification {
    String message;
    String time;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
