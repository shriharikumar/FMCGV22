package com.bizsoft.fmcgv2.dataobject;

/**
 * Created by shri on 16/8/17.
 */

public class ProductReport {

    String ProductName;
    String Amount;

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public String getAmount() {
        return Amount;
    }

    public void setAmount(String amount) {
        Amount = amount;
    }
}
