package com.bizsoft.fmcgv2.Tables;

/**
 * Created by GopiKing on 01-03-2018.
 */

public class BankNameList {


}
