package com.bizsoft.fmcgv2.dataobject;

/**
 * Created by shri on 11/8/17.
 */

public class ProductSaveResponse {

    Long Id;
    boolean HasError;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public boolean isHasError() {
        return HasError;
    }

    public void setHasError(boolean hasError) {
        HasError = hasError;
    }
}
