package com.bizsoft.fmcgv2.dataobject;

/**
 * Created by GopiKing on 20-12-2017.
 */

public class ReceiverResponse {

    String H;
    String M;

    public String getH() {
        return H;
    }

    public void setH(String h) {
        H = h;
    }

    public String getM() {
        return M;
    }

    public void setM(String m) {
        M = m;
    }

    public Object isA() {
        return A;
    }

    public void setA(Object a) {
        A = a;
    }

    Object A;
}
