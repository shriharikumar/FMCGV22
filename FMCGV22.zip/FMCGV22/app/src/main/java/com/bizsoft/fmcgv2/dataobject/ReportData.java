package com.bizsoft.fmcgv2.dataobject;

import java.util.ArrayList;

/**
 * Created by shri on 18/8/17.
 */

public class ReportData {

    String HasError;
    public ArrayList<Product> Datas = new ArrayList<>();
}
