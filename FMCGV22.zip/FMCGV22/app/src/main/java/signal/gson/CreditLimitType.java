package signal.gson;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("com.robohorse.robopojogenerator")
public class CreditLimitType{

	@SerializedName("Id")
	private int id;

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	@Override
 	public String toString(){
		return 
			"CreditLimitType{" + 
			"id = '" + id + '\'' + 
			"}";
		}
}